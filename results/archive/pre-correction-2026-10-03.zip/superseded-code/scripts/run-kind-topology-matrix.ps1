param(
    [string[]]$Profiles = @("small", "homogeneous", "skewed"),
    [int]$Repetitions = 3,
    [int]$Seed = 2026,
    [double]$PriorityDelaySeconds = 7,
    [switch]$SkipBuild,
    [switch]$SkipNetworkShaping
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$python = Join-Path $root ".venv\Scripts\python.exe"
$gitBash = "C:\Program Files\Git\usr\bin\bash.exe"
$images = @(
    "ts-control-plane:v1",
    "ts-fileserver:v1",
    "ts-bw-probe:v1",
    "ts-thermal:v1",
    "ts-task-io:v1",
    "ts-task-mem:v1",
    "ts-task-cpu:v1"
)

if (-not (Test-Path $python)) {
    throw "Python virtual environment not found at $python"
}
if (-not (Test-Path $gitBash)) {
    throw "Git Bash not found at $gitBash"
}
if ($Repetitions -lt 1) {
    throw "Repetitions must be at least 1"
}

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )
    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "$Command failed with exit code $LASTEXITCODE"
    }
}

if (-not $SkipBuild) {
    $builds = @(
        @{
            Image = "ts-control-plane:v1"
            Arguments = @(
                "build", "-t", "ts-control-plane:v1",
                "-f", "images/control-plane/Dockerfile", "."
            )
        },
        @{
            Image = "ts-fileserver:v1"
            Arguments = @("build", "-t", "ts-fileserver:v1", "images/fileserver")
        },
        @{
            Image = "ts-bw-probe:v1"
            Arguments = @("build", "-t", "ts-bw-probe:v1", "images/bw-probe")
        },
        @{
            Image = "ts-thermal:v1"
            Arguments = @("build", "-t", "ts-thermal:v1", "images/thermal")
        },
        @{
            Image = "ts-task-io:v1"
            Arguments = @(
                "build", "-t", "ts-task-io:v1",
                "-f", "tasks/task_io/Dockerfile", "."
            )
        },
        @{
            Image = "ts-task-mem:v1"
            Arguments = @(
                "build", "-t", "ts-task-mem:v1",
                "-f", "tasks/task_mem/Dockerfile", "."
            )
        },
        @{
            Image = "ts-task-cpu:v1"
            Arguments = @(
                "build", "-t", "ts-task-cpu:v1",
                "-f", "tasks/task_cpu/Dockerfile", "."
            )
        }
    )
    foreach ($build in $builds) {
        Write-Host "=== Building $($build.Image) ==="
        Invoke-Checked -Command docker -Arguments $build.Arguments
    }
}

$resultDirectory = Join-Path $root "results\k8s-kind-topologies"
New-Item -ItemType Directory -Force -Path $resultDirectory | Out-Null

foreach ($profile in $Profiles) {
    Write-Host "=== Creating Kind topology: $profile ==="
    Invoke-Checked $gitBash @("setup_cluster.sh", $profile)

    foreach ($image in $images) {
        Invoke-Checked kind @(
            "load", "docker-image", $image, "--name", "ts-cluster"
        )
    }

    if (-not $SkipNetworkShaping) {
        $networkOutput = Join-Path $resultDirectory "$profile-network.json"
        Invoke-Checked $python @(
            "configure_kind_network.py", $profile,
            "--output", $networkOutput
        )
    }

    Invoke-Checked kubectl @("apply", "-k", ".")
    Invoke-Checked kubectl @(
        "-n", "ts-system", "rollout", "status",
        "deployment/ts-controller", "--timeout=180s"
    )
    Invoke-Checked kubectl @(
        "-n", "ts-system", "rollout", "status",
        "deployment/ts-scheduler", "--timeout=180s"
    )
    foreach ($daemonSet in @("ts-fileserver", "ts-bw-probe", "ts-thermal")) {
        Invoke-Checked kubectl @(
            "-n", "ts-system", "rollout", "status",
            "daemonset/$daemonSet", "--timeout=180s"
        )
    }

    $output = Join-Path $resultDirectory "$profile.json"
    Invoke-Checked $python @(
        "run_k8s_experiment.py",
        "--policies", "legacy-v1", "legacy-tuned", "adaptive",
        "--repetitions", "$Repetitions",
        "--seed", "$Seed",
        "--topology-name", $profile,
        "--priority-delay-seconds", "$PriorityDelaySeconds",
        "--timeout-seconds", "900",
        "--output", $output
    )
}

Write-Host "Kind topology matrix complete: $resultDirectory"