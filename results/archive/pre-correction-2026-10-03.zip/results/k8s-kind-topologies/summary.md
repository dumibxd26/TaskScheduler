# Multi-Topology Kind Summary

Single-PC Kind integration with Docker cgroup envelopes, accelerated task work, and deterministic worker-container netem; not independent physical-node or physical-link validation.

## Emulation Protocol

Logical scheduler demand is preserved while task images execute scaled physical work inside smaller Pod cgroup envelopes. Network rates and delays are deterministic worker-container egress settings.

| Topology | Worker | Delay (ms) | Rate (Mbit/s) | Observed qdisc |
|---|---|---:|---:|---|
| homogeneous | ts-node-equal-1 | 4 | 300 | `qdisc netem 8013: root refcnt 9 limit 1000 delay 4ms rate 300Mbit seed 17682288128410847600` |
| homogeneous | ts-node-equal-2 | 4 | 300 | `qdisc netem 8014: root refcnt 9 limit 1000 delay 4ms rate 300Mbit seed 15128697891862836985` |
| homogeneous | ts-node-equal-3 | 4 | 300 | `qdisc netem 8015: root refcnt 9 limit 1000 delay 4ms rate 300Mbit seed 5620412458411154068` |
| skewed | ts-node-cpu-fast | 8 | 100 | `qdisc netem 8016: root refcnt 9 limit 1000 delay 8ms rate 100Mbit seed 8931459903349019422` |
| skewed | ts-node-io-fast | 1 | 1e+03 | `qdisc netem 8018: root refcnt 9 limit 1000 delay 1ms rate 1Gbit seed 13051246558671752789` |
| skewed | ts-node-mem-large | 4 | 200 | `qdisc netem 8017: root refcnt 9 limit 1000 delay 4ms rate 200Mbit seed 16322138797973472141` |
| small | ts-node-cpu-1 | 4 | 250 | `qdisc netem 8010: root refcnt 9 limit 1000 delay 4ms rate 250Mbit seed 6214568441675852323` |
| small | ts-node-io-1 | 2 | 800 | `qdisc netem 8012: root refcnt 9 limit 1000 delay 2ms rate 800Mbit seed 11879498061942630711` |
| small | ts-node-mem-1 | 6 | 150 | `qdisc netem 8011: root refcnt 9 limit 1000 delay 6ms rate 150Mbit seed 13081447235937986410` |

## Executed Work Evidence

Ratios are medians of executed physical work divided by logical work. A value is `n/a` when that task class does not emit the quantity.

| Topology | Policy | Tasks with metrics | Work scales | Time scales | CPU ratio | Memory ratio | I/O ratio | Hold ratio |
|---|---|---:|---|---|---:|---:|---:|---:|
| homogeneous | adaptive | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| homogeneous | legacy-tuned | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| homogeneous | legacy-v1 | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| skewed | adaptive | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| skewed | legacy-tuned | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| skewed | legacy-v1 | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| small | adaptive | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| small | legacy-tuned | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |
| small | legacy-v1 | 60 | 0.1, 0.25, 0.5 | 0.25 | 0.250 | 0.250 | 0.100 | 0.250 |

## Data-Path Evidence

Every retained trial reconciles its pipeline producer bytes with the consumer bytes and requires a matching `[LOCAL]` or `[FETCH]` record. The local and remote counts therefore sum to the trial count in every row.

| Topology | Policy | Local reads | Remote fetches | Transfer seconds |
|---|---|---:|---:|---:|
| homogeneous | adaptive | 2 | 1 | 0.372 |
| homogeneous | legacy-tuned | 1 | 2 | 1.003 |
| homogeneous | legacy-v1 | 1 | 2 | 1.015 |
| skewed | adaptive | 2 | 1 | 0.177 |
| skewed | legacy-tuned | 2 | 1 | 0.530 |
| skewed | legacy-v1 | 1 | 2 | 0.789 |
| small | adaptive | 1 | 2 | 0.992 |
| small | legacy-tuned | 1 | 2 | 0.959 |
| small | legacy-v1 | 0 | 3 | 1.722 |

## Per Topology

| Topology | Policy | Completion | Median workflow (s) | P95 workflow (s) | Critical (s) | Makespan (s) | Preemptions | Restarts |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| homogeneous | adaptive | 100.00% | 29.065 | 60.705 | 18.773 | 55.724 | 15 | 0 |
| homogeneous | legacy-tuned | 100.00% | 34.801 | 43.032 | 18.954 | 47.277 | 0 | 0 |
| homogeneous | legacy-v1 | 100.00% | 34.066 | 42.658 | 18.919 | 43.566 | 0 | 0 |
| skewed | adaptive | 100.00% | 31.348 | 54.795 | 16.523 | 54.595 | 14 | 0 |
| skewed | legacy-tuned | 100.00% | 30.704 | 38.381 | 14.138 | 43.846 | 0 | 0 |
| skewed | legacy-v1 | 100.00% | 32.466 | 39.994 | 15.311 | 45.734 | 0 | 0 |
| small | adaptive | 100.00% | 31.904 | 59.114 | 14.623 | 57.090 | 13 | 0 |
| small | legacy-tuned | 100.00% | 38.748 | 50.650 | 18.409 | 50.650 | 0 | 0 |
| small | legacy-v1 | 100.00% | 35.094 | 52.804 | 16.641 | 46.187 | 0 | 0 |

## Per-Topology Workflow Shapes

| Topology | Policy | Shape | Median response (s) |
|---|---|---|---:|
| homogeneous | adaptive | critical | 18.773 |
| homogeneous | adaptive | fanout | 26.966 |
| homogeneous | adaptive | parallel | 29.065 |
| homogeneous | adaptive | pipeline | 29.128 |
| homogeneous | adaptive | pressure | 55.724 |
| homogeneous | legacy-tuned | critical | 18.954 |
| homogeneous | legacy-tuned | fanout | 36.181 |
| homogeneous | legacy-tuned | parallel | 34.135 |
| homogeneous | legacy-tuned | pipeline | 40.277 |
| homogeneous | legacy-tuned | pressure | 34.730 |
| homogeneous | legacy-v1 | critical | 18.919 |
| homogeneous | legacy-v1 | fanout | 34.509 |
| homogeneous | legacy-v1 | parallel | 30.390 |
| homogeneous | legacy-v1 | pipeline | 36.566 |
| homogeneous | legacy-v1 | pressure | 33.167 |
| skewed | adaptive | critical | 16.523 |
| skewed | adaptive | fanout | 33.410 |
| skewed | adaptive | parallel | 29.311 |
| skewed | adaptive | pipeline | 31.348 |
| skewed | adaptive | pressure | 54.595 |
| skewed | legacy-tuned | critical | 14.138 |
| skewed | legacy-tuned | fanout | 34.305 |
| skewed | legacy-tuned | parallel | 30.704 |
| skewed | legacy-tuned | pipeline | 36.831 |
| skewed | legacy-tuned | pressure | 28.475 |
| skewed | legacy-v1 | critical | 15.311 |
| skewed | legacy-v1 | fanout | 33.887 |
| skewed | legacy-v1 | parallel | 26.227 |
| skewed | legacy-v1 | pipeline | 38.721 |
| skewed | legacy-v1 | pressure | 30.682 |
| small | adaptive | critical | 14.623 |
| small | adaptive | fanout | 33.518 |
| small | adaptive | parallel | 31.463 |
| small | adaptive | pipeline | 31.904 |
| small | adaptive | pressure | 57.090 |
| small | legacy-tuned | critical | 18.409 |
| small | legacy-tuned | fanout | 38.748 |
| small | legacy-tuned | parallel | 32.491 |
| small | legacy-tuned | pipeline | 42.816 |
| small | legacy-tuned | pressure | 49.792 |
| small | legacy-v1 | critical | 16.641 |
| small | legacy-v1 | fanout | 35.094 |
| small | legacy-v1 | parallel | 29.407 |
| small | legacy-v1 | pipeline | 37.637 |
| small | legacy-v1 | pressure | 46.187 |

## Aggregate

| Policy | Trials | Completion | Median workflow (s) | P95 workflow (s) | Critical (s) | Makespan (s) | Preemptions | Restarts |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| adaptive | 9 | 100.00% | 31.300 | 57.090 | 16.523 | 54.795 | 42 | 0 |
| legacy-tuned | 9 | 100.00% | 34.730 | 48.682 | 17.354 | 47.277 | 0 | 0 |
| legacy-v1 | 9 | 100.00% | 33.544 | 46.187 | 17.575 | 45.734 | 0 | 0 |

## Aggregate Workflow Shapes

| Policy | Shape | Median response (s) |
|---|---|---:|
| adaptive | critical | 16.523 |
| adaptive | fanout | 29.168 |
| adaptive | parallel | 31.300 |
| adaptive | pipeline | 31.348 |
| adaptive | pressure | 54.795 |
| legacy-tuned | critical | 17.354 |
| legacy-tuned | fanout | 36.181 |
| legacy-tuned | parallel | 32.268 |
| legacy-tuned | pipeline | 40.277 |
| legacy-tuned | pressure | 34.730 |
| legacy-v1 | critical | 17.575 |
| legacy-v1 | fanout | 34.509 |
| legacy-v1 | parallel | 29.969 |
| legacy-v1 | pipeline | 37.637 |
| legacy-v1 | pressure | 34.626 |

## Profile-Learning Sequence

Profiles are reused only within a policy and topology. Sequential values are descriptive and also include host/order effects.

| Scope | Policy | Repetition | Trials | Makespan (s) | Mean response (s) |
|---|---|---:|---:|---:|---:|
| homogeneous | adaptive | 1 | 1 | 55.724 | 30.843 |
| homogeneous | adaptive | 2 | 1 | 51.088 | 32.161 |
| homogeneous | adaptive | 3 | 1 | 60.705 | 32.021 |
| homogeneous | legacy-tuned | 1 | 1 | 47.277 | 32.855 |
| homogeneous | legacy-tuned | 2 | 1 | 50.032 | 37.235 |
| homogeneous | legacy-tuned | 3 | 1 | 41.811 | 28.506 |
| homogeneous | legacy-v1 | 1 | 1 | 49.658 | 34.944 |
| homogeneous | legacy-v1 | 2 | 1 | 43.566 | 30.441 |
| homogeneous | legacy-v1 | 3 | 1 | 43.123 | 30.347 |
| skewed | adaptive | 1 | 1 | 52.441 | 28.616 |
| skewed | adaptive | 2 | 1 | 54.595 | 38.343 |
| skewed | adaptive | 3 | 1 | 54.795 | 33.077 |
| skewed | legacy-tuned | 1 | 1 | 45.381 | 30.157 |
| skewed | legacy-tuned | 2 | 1 | 43.846 | 29.435 |
| skewed | legacy-tuned | 3 | 1 | 41.922 | 27.240 |
| skewed | legacy-v1 | 1 | 1 | 45.734 | 31.201 |
| skewed | legacy-v1 | 2 | 1 | 43.720 | 26.690 |
| skewed | legacy-v1 | 3 | 1 | 46.994 | 31.505 |
| small | adaptive | 1 | 1 | 57.090 | 30.203 |
| small | adaptive | 2 | 1 | 53.358 | 34.463 |
| small | adaptive | 3 | 1 | 59.114 | 35.255 |
| small | legacy-tuned | 1 | 1 | 49.816 | 36.621 |
| small | legacy-tuned | 2 | 1 | 50.727 | 36.379 |
| small | legacy-tuned | 3 | 1 | 50.650 | 35.933 |
| small | legacy-v1 | 1 | 1 | 54.906 | 38.742 |
| small | legacy-v1 | 2 | 1 | 44.637 | 31.958 |
| small | legacy-v1 | 3 | 1 | 46.187 | 31.870 |
| all-topology median | adaptive | 1 | 3 | 55.724 | 30.203 |
| all-topology median | adaptive | 2 | 3 | 53.358 | 34.463 |
| all-topology median | adaptive | 3 | 3 | 59.114 | 33.077 |
| all-topology median | legacy-tuned | 1 | 3 | 47.277 | 32.855 |
| all-topology median | legacy-tuned | 2 | 3 | 50.032 | 36.379 |
| all-topology median | legacy-tuned | 3 | 3 | 41.922 | 28.506 |
| all-topology median | legacy-v1 | 1 | 3 | 49.658 | 34.944 |
| all-topology median | legacy-v1 | 2 | 3 | 43.720 | 30.441 |
| all-topology median | legacy-v1 | 3 | 3 | 46.187 | 31.505 |

## Timing Comparisons

Negative values favor the policy left of `vs`; positive values favor the policy on the right.

| Scope | Comparison | Median workflow | P95 workflow | Critical | Makespan |
|---|---|---:|---:|---:|---:|
| homogeneous | tuned vs v1 | +2.16% | +0.88% | +0.18% | +8.52% |
| homogeneous | Adaptive vs tuned | -16.48% | +41.07% | -0.95% | +17.87% |
| skewed | tuned vs v1 | -5.43% | -4.03% | -7.66% | -4.13% |
| skewed | Adaptive vs tuned | +2.10% | +42.77% | +16.87% | +24.52% |
| small | tuned vs v1 | +10.41% | -4.08% | +10.63% | +9.66% |
| small | Adaptive vs tuned | -17.66% | +16.71% | -20.56% | +12.72% |
| aggregate | tuned vs v1 | +3.54% | +5.40% | -1.25% | +3.37% |
| aggregate | Adaptive vs tuned | -9.88% | +17.27% | -4.79% | +15.90% |

## Tuned Legacy Direction Check

- `median_workflow_response_s`: tuned Legacy is lower in 1/3 topologies.
- `p95_workflow_response_s`: tuned Legacy is lower in 2/3 topologies.
- `median_critical_response_s`: tuned Legacy is lower in 1/3 topologies.
- `median_trial_makespan_s`: tuned Legacy is lower in 1/3 topologies.

