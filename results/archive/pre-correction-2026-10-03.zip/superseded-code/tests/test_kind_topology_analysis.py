from pathlib import Path

import pytest

from analyze_kind_topologies import (
    _comparison,
    _policy_metrics,
    _validate_network_sidecar,
    _validate_trial,
)


def test_comparison_reports_left_over_right_ratios():
    left = {
        "median_workflow_response_s": 8,
        "p95_workflow_response_s": 10,
        "median_critical_response_s": 6,
        "median_trial_makespan_s": 12,
    }
    right = {
        "median_workflow_response_s": 10,
        "p95_workflow_response_s": 10,
        "median_critical_response_s": 8,
        "median_trial_makespan_s": 15,
    }

    assert _comparison(left, right) == {
        "median_workflow_response_s": 0.8,
        "p95_workflow_response_s": 1.0,
        "median_critical_response_s": 0.75,
        "median_trial_makespan_s": 0.8,
    }


def test_policy_metrics_aggregates_live_trials():
    trial = {
        "repetition": 1,
        "makespan_seconds": 12.0,
        "mean_response_seconds": 8.0,
        "preemptions": 1,
        "scheduler_events": {"error_lines": []},
        "workflows": [{
            "shape": "critical",
            "state": "FINISHED",
            "response_seconds": 8.0,
            "tasks_failed": 0,
            "tasks": [{
                "transfer_mode": "remote",
                "state": "FINISHED",
                "pod_phase": "Succeeded",
                "restart_count": 0,
                    "metrics": {
                        "transfer_seconds": 0.5,
                        "emulation": {
                            "work_scale": 0.25,
                            "time_scale": 0.5,
                            "logical_cpu_iterations": 100,
                            "physical_cpu_iterations": 25,
                        },
                    },
            }],
        }],
    }

    result = _policy_metrics([trial])

    assert result["completion_rate"] == 1
    assert result["median_critical_response_s"] == 8
    assert result["median_response_by_shape_s"] == {"critical": 8}
    assert result["median_trial_makespan_s"] == 12
    assert result["by_repetition"] == {
        "1": {
            "trials": 1,
            "median_trial_makespan_s": 12,
            "median_trial_mean_response_s": 8,
        }
    }
    assert result["preemptions"] == 1
    assert result["remote_fetches"] == 1
    assert result["transfer_seconds"] == 0.5
    assert result["container_restarts"] == 0
    assert result["emulation"] == {
        "tasks_with_metrics": 1,
        "work_scales": [0.25],
        "time_scales": [0.5],
        "cpu_work_ratio": 0.25,
        "memory_work_ratio": None,
        "io_work_ratio": None,
        "hold_time_ratio": None,
    }


def test_trial_validation_rejects_failed_final_task():
    tasks = [{
        "state": "FINISHED",
        "pod_phase": "Succeeded",
        "restart_count": 0,
        "metrics": {
            "emulation": {"work_scale": 0.25, "time_scale": 0.25},
        },
    } for _ in range(20)]
    tasks[0]["state"] = "FAILED"
    shapes = ["pressure", "critical", "pipeline", "fanout", "parallel"]
    trial = {
        "policy": "adaptive",
        "repetition": 1,
        "scheduler_events": {
            "binding_lines": ["bind"] * 20,
            "error_lines": [],
        },
        "workflows": [
            {
                "shape": shape,
                "state": "FINISHED",
                "tasks_failed": 0,
                "tasks": tasks[index * 4:(index + 1) * 4],
            }
            for index, shape in enumerate(shapes)
        ],
    }

    with pytest.raises(ValueError, match="non-successful final task"):
        _validate_trial(Path("result.json"), "adaptive", 1, trial)


def test_trial_validation_rejects_missing_emulation_metrics():
    tasks = [{
        "state": "FINISHED",
        "pod_phase": "Succeeded",
        "restart_count": 0,
        "metrics": {},
    } for _ in range(20)]
    shapes = ["pressure", "critical", "pipeline", "fanout", "parallel"]
    trial = {
        "policy": "adaptive",
        "repetition": 1,
        "scheduler_events": {
            "binding_lines": ["bind"] * 20,
            "error_lines": [],
        },
        "workflows": [
            {
                "shape": shape,
                "state": "FINISHED",
                "tasks_failed": 0,
                "tasks": tasks[index * 4:(index + 1) * 4],
            }
            for index, shape in enumerate(shapes)
        ],
    }

    with pytest.raises(ValueError, match="without emulation metrics"):
        _validate_trial(Path("result.json"), "adaptive", 1, trial)


def test_trial_validation_rejects_pipeline_that_skipped_parent_output():
    tasks = [{
        "state": "FINISHED",
        "pod_phase": "Succeeded",
        "restart_count": 0,
        "metrics": {
            "emulation": {"work_scale": 0.25, "time_scale": 0.25},
        },
    } for _ in range(20)]
    pipeline_tasks = tasks[8:12]
    pipeline_tasks[0].update({
        "name": "ingest",
        "metrics": {
            "emulation": {"work_scale": 0.1, "time_scale": 0.25},
            "output_bytes_by_field": {"generated_file_path": 10485760},
        },
    })
    pipeline_tasks[1].update({
        "name": "stage",
        "transfer_mode": None,
        "transfer_source": None,
        "metrics": {
            "emulation": {"work_scale": 0.1, "time_scale": 0.25},
            "io_bytes_read": 0,
            "transfer_seconds": 0.0,
        },
    })
    shapes = ["pressure", "critical", "pipeline", "fanout", "parallel"]
    trial = {
        "policy": "adaptive",
        "repetition": 1,
        "scheduler_events": {
            "binding_lines": ["bind"] * 20,
            "error_lines": [],
        },
        "workflows": [
            {
                "shape": shape,
                "state": "FINISHED",
                "tasks_failed": 0,
                "tasks": tasks[index * 4:(index + 1) * 4],
            }
            for index, shape in enumerate(shapes)
        ],
    }

    with pytest.raises(ValueError, match="did not consume its producer output"):
        _validate_trial(Path("result.json"), "adaptive", 1, trial)


def test_network_sidecar_matches_annotations_and_observed_qdisc(tmp_path):
    sidecar = tmp_path / "small-network.json"
    sidecar.write_text(
        """{
  "profile": "small",
  "operation": "apply",
  "dry_run": false,
  "workers": [{
    "node": "worker-1",
    "delay_ms": 4.0,
    "rate_mbit": 250.0,
    "interface": "eth0",
    "container": "kind-worker",
    "observed_qdisc": "qdisc netem 8001: root delay 4ms rate 250Mbit"
  }]
}
""",
        encoding="utf-8",
    )
    workers = [{
        "name": "worker-1",
        "netem_delay_ms": "4",
        "netem_rate_mbit": "250",
    }]

    assert _validate_network_sidecar(sidecar, "small", workers) == {
        "worker-1": {
            "delay_ms": 4.0,
            "rate_mbit": 250.0,
            "interface": "eth0",
            "container": "kind-worker",
            "observed_qdisc": (
                "qdisc netem 8001: root delay 4ms rate 250Mbit"),
        }
    }


def test_network_sidecar_rejects_annotation_mismatch(tmp_path):
    sidecar = tmp_path / "small-network.json"
    sidecar.write_text(
        """{
  "profile": "small",
  "operation": "apply",
  "dry_run": false,
  "workers": [{
    "node": "worker-1",
    "delay_ms": 6.0,
    "rate_mbit": 250.0,
    "observed_qdisc": "qdisc netem 8001: root delay 6ms rate 250Mbit"
  }]
}
""",
        encoding="utf-8",
    )
    workers = [{
        "name": "worker-1",
        "netem_delay_ms": "4",
        "netem_rate_mbit": "250",
    }]

    with pytest.raises(ValueError, match="disagrees with node annotations"):
        _validate_network_sidecar(sidecar, "small", workers)